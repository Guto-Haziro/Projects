<!DOCTYPE html>
<html>
  <head>
    <title>AWS Cloud Treinamentos</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
  </head>

  <body style="background-color:black">
    <div class="container">

      <div class="row">
    		<div class="col-md-12">
      <?php include('menu.php'); ?>
      <div class="jumbotron" style="background-color:#555; color:#fff">

     <h1>
        Calma, segura a ansiedade!!!          
     </h1>
    <p>
        Na AULA 3 (quinta-feira) você vai ver o <b>Pulo do Gato</b>.           
     </p>
    <p>
        Já clica no link abaixo e define o lembrete na Aula 3 para não perder.           
     </p>
		  <a target="_blank" style="font-size:26px" href="https://www.youtube.com/watch?v=EgqhF72rTuQ&list=PLwlq4XZ8aTmeYcljfKgWbeWQqD2W25eZM&index=3"><b><u>ACESSAR AULA 3 NO YOUTUBE</u></b></a>

</br>
<div class="embed-responsive embed-responsive-16by9">
  .<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/EgqhF72rTuQ" allowfullscreen=""></iframe>
</div>

  </div>


</div>
</div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>
  </body>
</html>
