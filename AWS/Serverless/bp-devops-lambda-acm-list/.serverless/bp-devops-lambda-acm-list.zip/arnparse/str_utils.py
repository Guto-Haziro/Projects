def empty_str_to_none(str_):
    if str_ == '':
        return None

    return str_
