import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='danielmagalhaesdonascimento',
    application_name='my-certificate-checker',
    app_uid='9zkB9cwRpsmpklmSRh',
    org_uid='f05d7f52-b9c8-4cee-a140-fc1b9d077c90',
    deployment_uid='f9e379b5-4bb9-4966-bbd5-795d9c0d680c',
    service_name='bp-devops-lambda-acm-list',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='7.2.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'bp-devops-lambda-acm-list-dev-certificateChecker', 'timeout': 20}
try:
    user_handler = serverless_sdk.get_user_handler('lambda_function.lambda_handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
